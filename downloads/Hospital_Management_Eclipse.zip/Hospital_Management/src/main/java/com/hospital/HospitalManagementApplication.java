package com.hospital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableAsync
@EnableScheduling
public class HospitalManagementApplication {

    public static void main(String[] args) {
        com.hospital.config.LocalEnvLoader.load();
        SpringApplication.run(HospitalManagementApplication.class, args);
    }
}
